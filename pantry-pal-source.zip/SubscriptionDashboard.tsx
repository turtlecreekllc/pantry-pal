/**
 * SubscriptionDashboard Component
 * Displays subscription status, token balance, and management options
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSubscription, PLAN_PRICING, TOKEN_BUCKETS } from '../hooks/useSubscription';
import { Button } from './ui/Button';

interface SubscriptionDashboardProps {
  onViewHistory?: () => void;
  onUpgrade?: () => void;
}

export function SubscriptionDashboard({ onViewHistory, onUpgrade }: SubscriptionDashboardProps) {
  const {
    loading,
    error,
    isPremium,
    isTrial,
    isTrialExpired,
    tier,
    daysUntilRenewal,
    daysUntilTrialEnd,
    totalTokens,
    tokenUsagePercent,
    subscriptionTokens,
    purchasedTokens,
    rolloverTokens,
    openCheckout,
    openTokenPurchase,
    openCustomerPortal,
    cancelSubscription,
    resumeSubscription,
    getSavings,
    state,
  } = useSubscription();
  const [savings, setSavings] = useState({ itemsSaved: 0, moneySaved: 0, co2Avoided: 0 });
  const [loadingSavings, setLoadingSavings] = useState(true);
  useEffect(() => {
    getSavings('month').then(data => {
      setSavings(data);
      setLoadingSavings(false);
    });
  }, [getSavings]);
  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#4CAF50" />
        <Text style={styles.loadingText}>Loading subscription...</Text>
      </View>
    );
  }
  if (error) {
    return (
      <View style={styles.errorContainer}>
        <Ionicons name="alert-circle" size={48} color="#f44336" />
        <Text style={styles.errorText}>{error}</Text>
      </View>
    );
  }
  const handleCancelSubscription = () => {
    Alert.alert(
      'Cancel Subscription',
      `You've saved an estimated $${savings.moneySaved.toFixed(2)} this month. Are you sure you want to cancel?`,
      [
        { text: 'Keep Subscription', style: 'cancel' },
        {
          text: 'Cancel',
          style: 'destructive',
          onPress: async () => {
            const result = await cancelSubscription();
            if (result.success) {
              Alert.alert('Subscription Canceled', 'Your subscription will remain active until the end of your billing period.');
            } else {
              Alert.alert('Error', result.error || 'Failed to cancel subscription');
            }
          },
        },
      ]
    );
  };
  const handleBuyTokens = () => {
    Alert.alert(
      'Buy More Tokens',
      'Choose a token bucket:',
      TOKEN_BUCKETS.map(bucket => ({
        text: `${bucket.size} tokens - ${bucket.displayPrice}`,
        onPress: () => openTokenPurchase(bucket.size as 50 | 150 | 400),
      })).concat([{ text: 'Cancel', style: 'cancel' as const, onPress: () => {} }])
    );
  };
  const renderPremiumDashboard = () => (
    <>
      {/* Plan Status Card */}
      <View style={styles.statusCard}>
        <View style={styles.statusHeader}>
          <View style={styles.planBadge}>
            <Ionicons name="star" size={20} color="#FFD700" />
            <Text style={styles.planBadgeText}>
              {tier === 'premium_annual' ? 'Annual' : tier === 'trial' ? 'Trial' : 'Monthly'}
            </Text>
          </View>
          <Text style={styles.statusActive}>Active</Text>
        </View>
        <View style={styles.statusDetails}>
          <View style={styles.statusRow}>
            <Text style={styles.statusLabel}>
              {isTrial ? 'Trial ends in' : 'Renews in'}
            </Text>
            <Text style={styles.statusValue}>
              {isTrial
                ? `${daysUntilTrialEnd} days`
                : `${daysUntilRenewal} days`}
            </Text>
          </View>
          <View style={styles.statusRow}>
            <Text style={styles.statusLabel}>Price</Text>
            <Text style={styles.statusValue}>
              {isTrial
                ? 'Free Trial'
                : tier === 'premium_annual'
                ? PLAN_PRICING.premium_annual.displayPrice + '/year'
                : PLAN_PRICING.premium_monthly.displayPrice + '/month'}
            </Text>
          </View>
        </View>
        {!isTrial && (
          <TouchableOpacity style={styles.manageButton} onPress={openCustomerPortal}>
            <Text style={styles.manageButtonText}>Manage Subscription</Text>
            <Ionicons name="open-outline" size={16} color="#4CAF50" />
          </TouchableOpacity>
        )}
      </View>
      {/* Token Balance Card */}
      <View style={styles.tokenCard}>
        <Text style={styles.tokenCardTitle}>AI Tokens</Text>
        <View style={styles.tokenBalance}>
          <Text style={styles.tokenAmount}>{totalTokens}</Text>
          <Text style={styles.tokenLabel}>available</Text>
        </View>
        {/* Token Usage Meter */}
        <View style={styles.usageMeter}>
          <View style={styles.usageMeterBackground}>
            <View
              style={[
                styles.usageMeterFill,
                {
                  width: `${Math.min(tokenUsagePercent, 100)}%`,
                  backgroundColor: tokenUsagePercent >= 80 ? '#FF9800' : '#4CAF50',
                },
              ]}
            />
          </View>
          <Text style={styles.usageMeterText}>{tokenUsagePercent}% used this month</Text>
        </View>
        {/* Token Breakdown */}
        <View style={styles.tokenBreakdown}>
          <View style={styles.tokenBreakdownRow}>
            <View style={[styles.tokenDot, { backgroundColor: '#4CAF50' }]} />
            <Text style={styles.tokenBreakdownLabel}>Monthly</Text>
            <Text style={styles.tokenBreakdownValue}>{subscriptionTokens}</Text>
          </View>
          <View style={styles.tokenBreakdownRow}>
            <View style={[styles.tokenDot, { backgroundColor: '#2196F3' }]} />
            <Text style={styles.tokenBreakdownLabel}>Purchased</Text>
            <Text style={styles.tokenBreakdownValue}>{purchasedTokens}</Text>
          </View>
          {tier === 'premium_annual' && (
            <View style={styles.tokenBreakdownRow}>
              <View style={[styles.tokenDot, { backgroundColor: '#9C27B0' }]} />
              <Text style={styles.tokenBreakdownLabel}>Rollover</Text>
              <Text style={styles.tokenBreakdownValue}>{rolloverTokens}</Text>
            </View>
          )}
        </View>
        {/* Token Actions */}
        <View style={styles.tokenActions}>
          {totalTokens < 30 && (
            <Button
              title="Buy More Tokens"
              onPress={handleBuyTokens}
              style={styles.buyTokensButton}
            />
          )}
          <TouchableOpacity style={styles.viewHistoryButton} onPress={onViewHistory}>
            <Text style={styles.viewHistoryText}>View Usage History</Text>
            <Ionicons name="chevron-forward" size={16} color="#666" />
          </TouchableOpacity>
        </View>
      </View>
      {/* Savings Card */}
      {!loadingSavings && savings.moneySaved > 0 && (
        <View style={styles.savingsCard}>
          <View style={styles.savingsHeader}>
            <Ionicons name="leaf" size={24} color="#4CAF50" />
            <Text style={styles.savingsTitle}>Your Impact This Month</Text>
          </View>
          <View style={styles.savingsGrid}>
            <View style={styles.savingsItem}>
              <Text style={styles.savingsValue}>${savings.moneySaved.toFixed(0)}</Text>
              <Text style={styles.savingsLabel}>Saved</Text>
            </View>
            <View style={styles.savingsItem}>
              <Text style={styles.savingsValue}>{savings.itemsSaved}</Text>
              <Text style={styles.savingsLabel}>Items Rescued</Text>
            </View>
            <View style={styles.savingsItem}>
              <Text style={styles.savingsValue}>{savings.co2Avoided.toFixed(1)}kg</Text>
              <Text style={styles.savingsLabel}>CO₂ Avoided</Text>
            </View>
          </View>
        </View>
      )}
      {/* Cancel Option */}
      {!isTrial && !state?.subscription?.cancel_at_period_end && (
        <TouchableOpacity style={styles.cancelButton} onPress={handleCancelSubscription}>
          <Text style={styles.cancelButtonText}>Cancel Subscription</Text>
        </TouchableOpacity>
      )}
      {state?.subscription?.cancel_at_period_end && (
        <View style={styles.canceledBanner}>
          <Ionicons name="information-circle" size={20} color="#FF9800" />
          <Text style={styles.canceledText}>
            Your subscription will end on {new Date(state.subscription.current_period_end || '').toLocaleDateString()}
          </Text>
          <TouchableOpacity onPress={resumeSubscription}>
            <Text style={styles.resumeText}>Resume</Text>
          </TouchableOpacity>
        </View>
      )}
    </>
  );
  const renderFreeDashboard = () => (
    <>
      {/* Upgrade Card */}
      <View style={styles.upgradeCard}>
        <View style={styles.upgradeHeader}>
          <Ionicons name="rocket" size={32} color="#4CAF50" />
          <Text style={styles.upgradeTitle}>Upgrade to Premium</Text>
          <Text style={styles.upgradeSubtitle}>
            Unlock AI meal planning and save $100+/month
          </Text>
        </View>
        {/* ROI Callout */}
        <View style={styles.roiCallout}>
          <Ionicons name="cash-outline" size={20} color="#4CAF50" />
          <Text style={styles.roiText}>
            Pays for itself after saving just ONE ingredient from the trash
          </Text>
        </View>
        {/* Plan Options */}
        <View style={styles.planOptions}>
          <TouchableOpacity
            style={styles.planOption}
            onPress={() => openCheckout('premium_monthly')}
          >
            <Text style={styles.planOptionName}>Monthly</Text>
            <Text style={styles.planOptionPrice}>{PLAN_PRICING.premium_monthly.displayPrice}</Text>
            <Text style={styles.planOptionPeriod}>/month</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.planOption, styles.planOptionRecommended]}
            onPress={() => openCheckout('premium_annual')}
          >
            <View style={styles.recommendedBadge}>
              <Text style={styles.recommendedBadgeText}>Save 18%</Text>
            </View>
            <Text style={[styles.planOptionName, styles.planOptionNameSelected]}>Annual</Text>
            <Text style={[styles.planOptionPrice, styles.planOptionPriceSelected]}>
              {PLAN_PRICING.premium_annual.monthlyEquivalent}
            </Text>
            <Text style={styles.planOptionPeriod}>/month</Text>
          </TouchableOpacity>
        </View>
        {/* Trial Option */}
        {!isTrialExpired && (
          <TouchableOpacity
            style={styles.trialButton}
            onPress={async () => {
              const { startTrial } = useSubscription();
              const result = await startTrial();
              if (!result.success) {
                Alert.alert('Error', result.error || 'Failed to start trial');
              }
            }}
          >
            <Text style={styles.trialButtonText}>Start 14-Day Free Trial</Text>
            <Text style={styles.trialButtonSubtext}>No credit card required</Text>
          </TouchableOpacity>
        )}
      </View>
      {/* Feature Comparison */}
      <View style={styles.featuresCard}>
        <Text style={styles.featuresTitle}>What you'll get</Text>
        {[
          { icon: 'sparkles', text: '100 AI tokens/month', premium: true },
          { icon: 'infinite', text: 'Unlimited pantry items', premium: true },
          { icon: 'barcode', text: 'Unlimited barcode scans', premium: true },
          { icon: 'people', text: 'Household sharing (6 members)', premium: true },
          { icon: 'restaurant', text: 'AI recipe generation', premium: true },
          { icon: 'calendar', text: 'AI meal planning', premium: true },
          { icon: 'analytics', text: 'Full nutrition tracking', premium: true },
        ].map((feature, index) => (
          <View key={index} style={styles.featureRow}>
            <Ionicons
              name={feature.icon as any}
              size={20}
              color={feature.premium ? '#4CAF50' : '#ccc'}
            />
            <Text style={styles.featureText}>{feature.text}</Text>
            <Ionicons
              name="checkmark-circle"
              size={20}
              color="#4CAF50"
            />
          </View>
        ))}
      </View>
      {/* Current Limits */}
      <View style={styles.limitsCard}>
        <Text style={styles.limitsTitle}>Your Free Tier Limits</Text>
        <View style={styles.limitRow}>
          <Text style={styles.limitLabel}>Pantry Items</Text>
          <Text style={styles.limitValue}>
            {state?.usageLimits?.pantry_items_count || 0}/50
          </Text>
        </View>
        <View style={styles.limitRow}>
          <Text style={styles.limitLabel}>Saved Recipes</Text>
          <Text style={styles.limitValue}>
            {state?.usageLimits?.saved_recipes_count || 0}/25
          </Text>
        </View>
        <View style={styles.limitRow}>
          <Text style={styles.limitLabel}>Barcode Scans</Text>
          <Text style={styles.limitValue}>
            {state?.usageLimits?.barcode_scans_count || 0}/10
          </Text>
        </View>
      </View>
    </>
  );
  return (
    <View style={styles.container}>
      {isPremium || isTrial ? renderPremiumDashboard() : renderFreeDashboard()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#666',
  },
  errorContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  errorText: {
    marginTop: 12,
    fontSize: 16,
    color: '#f44336',
    textAlign: 'center',
  },
  // Premium Dashboard Styles
  statusCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  statusHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  planBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF8E1',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  planBadgeText: {
    marginLeft: 6,
    fontSize: 14,
    fontWeight: '600',
    color: '#F9A825',
  },
  statusActive: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4CAF50',
  },
  statusDetails: {
    gap: 8,
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  statusLabel: {
    fontSize: 14,
    color: '#666',
  },
  statusValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  manageButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 16,
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  manageButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4CAF50',
    marginRight: 4,
  },
  // Token Card Styles
  tokenCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  tokenCardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 12,
  },
  tokenBalance: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 16,
  },
  tokenAmount: {
    fontSize: 48,
    fontWeight: '700',
    color: '#4CAF50',
  },
  tokenLabel: {
    fontSize: 18,
    color: '#666',
    marginLeft: 8,
  },
  usageMeter: {
    marginBottom: 16,
  },
  usageMeterBackground: {
    height: 8,
    backgroundColor: '#e0e0e0',
    borderRadius: 4,
    overflow: 'hidden',
  },
  usageMeterFill: {
    height: '100%',
    borderRadius: 4,
  },
  usageMeterText: {
    fontSize: 12,
    color: '#666',
    marginTop: 4,
  },
  tokenBreakdown: {
    marginBottom: 16,
  },
  tokenBreakdownRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  tokenDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 8,
  },
  tokenBreakdownLabel: {
    flex: 1,
    fontSize: 14,
    color: '#666',
  },
  tokenBreakdownValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
  tokenActions: {
    gap: 12,
  },
  buyTokensButton: {
    backgroundColor: '#4CAF50',
  },
  viewHistoryButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
  },
  viewHistoryText: {
    fontSize: 14,
    color: '#666',
  },
  // Savings Card Styles
  savingsCard: {
    backgroundColor: '#E8F5E9',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
  },
  savingsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  savingsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2E7D32',
    marginLeft: 8,
  },
  savingsGrid: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  savingsItem: {
    alignItems: 'center',
  },
  savingsValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#2E7D32',
  },
  savingsLabel: {
    fontSize: 12,
    color: '#4CAF50',
    marginTop: 4,
  },
  // Cancel Button Styles
  cancelButton: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  cancelButtonText: {
    fontSize: 14,
    color: '#999',
  },
  canceledBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF3E0',
    padding: 12,
    borderRadius: 8,
    marginTop: 8,
  },
  canceledText: {
    flex: 1,
    fontSize: 13,
    color: '#E65100',
    marginLeft: 8,
  },
  resumeText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4CAF50',
  },
  // Free Dashboard Styles
  upgradeCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 24,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  upgradeHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  upgradeTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    marginTop: 12,
  },
  upgradeSubtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginTop: 8,
  },
  roiCallout: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    padding: 12,
    borderRadius: 8,
    marginBottom: 20,
  },
  roiText: {
    flex: 1,
    fontSize: 13,
    color: '#2E7D32',
    marginLeft: 8,
  },
  planOptions: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 16,
  },
  planOption: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
  },
  planOptionRecommended: {
    borderColor: '#4CAF50',
    backgroundColor: '#E8F5E9',
  },
  recommendedBadge: {
    position: 'absolute',
    top: -10,
    backgroundColor: '#FF9800',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
  },
  recommendedBadgeText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#fff',
  },
  planOptionName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#666',
    marginBottom: 4,
  },
  planOptionNameSelected: {
    color: '#333',
  },
  planOptionPrice: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
  },
  planOptionPriceSelected: {
    color: '#4CAF50',
  },
  planOptionPeriod: {
    fontSize: 12,
    color: '#999',
  },
  trialButton: {
    alignItems: 'center',
    paddingVertical: 16,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
    marginTop: 8,
  },
  trialButtonText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4CAF50',
  },
  trialButtonSubtext: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  // Features Card Styles
  featuresCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  featuresTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  featureText: {
    flex: 1,
    fontSize: 14,
    color: '#333',
    marginLeft: 12,
  },
  // Limits Card Styles
  limitsCard: {
    backgroundColor: '#fff',
    borderRadius: 16,
    padding: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  limitsTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  limitRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  limitLabel: {
    fontSize: 14,
    color: '#666',
  },
  limitValue: {
    fontSize: 14,
    fontWeight: '600',
    color: '#333',
  },
});

