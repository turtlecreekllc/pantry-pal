import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { RecipePreview } from '../lib/types';
import { colors, typography, spacing, borderRadius, shadows } from '../lib/theme';

interface RecipeCardProps {
  recipe: RecipePreview;
  onPress: () => void;
}

/**
 * Brand-styled recipe card component with image and title overlay
 */
export function RecipeCard({ recipe, onPress }: RecipeCardProps): React.ReactElement {
  return (
    <TouchableOpacity
      style={styles.container}
      onPress={onPress}
      activeOpacity={0.7}
      accessibilityRole="button"
      accessibilityLabel={recipe.name}
    >
      <Image source={{ uri: recipe.thumbnail }} style={styles.image} />
      <View style={styles.overlay}>
        <Text style={styles.name} numberOfLines={2}>{recipe.name}</Text>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    margin: spacing.space1,
    borderRadius: borderRadius.lg,
    overflow: 'hidden',
    backgroundColor: colors.cream,
    aspectRatio: 1,
    borderWidth: 2,
    borderColor: colors.brown,
    ...shadows.sm,
  },
  image: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  overlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: colors.primary,
    paddingVertical: spacing.space2,
    paddingHorizontal: spacing.space3,
    borderTopWidth: 2,
    borderTopColor: colors.brown,
  },
  name: {
    fontFamily: 'Nunito-SemiBold',
    color: colors.brown,
    fontSize: typography.textSm,
    fontWeight: typography.fontSemibold,
    lineHeight: typography.textSm * 1.2,
  },
});
