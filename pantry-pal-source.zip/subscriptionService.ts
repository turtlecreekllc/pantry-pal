/**
 * Subscription Service
 * Handles Stripe integration and subscription management for DinnerPlans.ai
 */

import { supabase } from './supabase';
import {
  Subscription,
  TokenBalance,
  TokenTransaction,
  SubscriptionState,
  SubscriptionTier,
  UsageLimits,
  SavingsTracking,
  FeatureAccessResult,
  CreateCheckoutParams,
  CreateTokenPurchaseParams,
  PLAN_PRICING,
  TOKEN_BUCKETS,
  FREE_TIER_LIMITS,
} from './types';

// Stripe product IDs (configured in Stripe Dashboard)
const STRIPE_PRODUCTS = {
  premium_monthly: process.env.EXPO_PUBLIC_STRIPE_PRICE_MONTHLY || 'price_monthly',
  premium_annual: process.env.EXPO_PUBLIC_STRIPE_PRICE_ANNUAL || 'price_annual',
  tokens_50: process.env.EXPO_PUBLIC_STRIPE_PRICE_TOKENS_50 || 'price_tokens_50',
  tokens_150: process.env.EXPO_PUBLIC_STRIPE_PRICE_TOKENS_150 || 'price_tokens_150',
  tokens_400: process.env.EXPO_PUBLIC_STRIPE_PRICE_TOKENS_400 || 'price_tokens_400',
} as const;

/**
 * Get the current user's subscription
 */
export async function getSubscription(userId: string): Promise<Subscription | null> {
  const { data, error } = await supabase
    .from('subscriptions')
    .select('*')
    .eq('user_id', userId)
    .single();
  if (error && error.code !== 'PGRST116') {
    console.error('Error fetching subscription:', error);
    return null;
  }
  return data;
}

/**
 * Get the current user's token balance
 */
export async function getTokenBalance(userId: string): Promise<TokenBalance | null> {
  const { data, error } = await supabase
    .from('token_balances')
    .select('*')
    .eq('user_id', userId)
    .single();
  if (error && error.code !== 'PGRST116') {
    console.error('Error fetching token balance:', error);
    return null;
  }
  return data;
}

/**
 * Get usage limits for free tier tracking
 */
export async function getUsageLimits(userId: string): Promise<UsageLimits | null> {
  const currentMonth = new Date().toISOString().slice(0, 7) + '-01';
  const { data, error } = await supabase
    .from('usage_limits')
    .select('*')
    .eq('user_id', userId)
    .eq('period_start', currentMonth)
    .single();
  if (error && error.code !== 'PGRST116') {
    console.error('Error fetching usage limits:', error);
    return null;
  }
  return data;
}

/**
 * Get savings tracking for ROI messaging
 */
export async function getSavingsTracking(userId: string): Promise<SavingsTracking | null> {
  const currentMonth = new Date().toISOString().slice(0, 7) + '-01';
  const { data, error } = await supabase
    .from('savings_tracking')
    .select('*')
    .eq('user_id', userId)
    .eq('month_start', currentMonth)
    .single();
  if (error && error.code !== 'PGRST116') {
    console.error('Error fetching savings:', error);
    return null;
  }
  return data;
}

/**
 * Get token transaction history
 */
export async function getTokenTransactions(
  userId: string,
  options: {
    limit?: number;
    offset?: number;
    startDate?: string;
    endDate?: string;
    featureType?: string;
  } = {}
): Promise<TokenTransaction[]> {
  const { limit = 50, offset = 0, startDate, endDate, featureType } = options;
  let query = supabase
    .from('token_transactions')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);
  if (startDate) {
    query = query.gte('created_at', startDate);
  }
  if (endDate) {
    query = query.lte('created_at', endDate);
  }
  if (featureType) {
    query = query.eq('feature_type', featureType);
  }
  const { data, error } = await query;
  if (error) {
    console.error('Error fetching token transactions:', error);
    return [];
  }
  return data || [];
}

/**
 * Get complete subscription state for UI
 */
export async function getSubscriptionState(userId: string): Promise<SubscriptionState> {
  const [subscription, tokenBalance, usageLimits, savings] = await Promise.all([
    getSubscription(userId),
    getTokenBalance(userId),
    getUsageLimits(userId),
    getSavingsTracking(userId),
  ]);
  const tier = subscription?.tier || 'free';
  const isPremium = tier === 'premium_monthly' || tier === 'premium_annual';
  const isTrial = tier === 'trial';
  // Check if trial is expired
  let isTrialExpired = false;
  if (isTrial && subscription?.trial_end) {
    isTrialExpired = new Date(subscription.trial_end) < new Date();
  }
  // Calculate days until renewal
  let daysUntilRenewal: number | null = null;
  if (subscription?.current_period_end) {
    const endDate = new Date(subscription.current_period_end);
    const now = new Date();
    daysUntilRenewal = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  }
  // Calculate days until trial end
  let daysUntilTrialEnd: number | null = null;
  if (subscription?.trial_end) {
    const trialEnd = new Date(subscription.trial_end);
    const now = new Date();
    daysUntilTrialEnd = Math.ceil((trialEnd.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
  }
  // Calculate total tokens
  const totalTokens = tokenBalance
    ? tokenBalance.subscription_tokens + tokenBalance.purchased_tokens + tokenBalance.rollover_tokens
    : 0;
  // Calculate usage percentage
  const monthlyAllocation = isPremium || isTrial ? PLAN_PRICING.premium_monthly.tokens : 0;
  const tokenUsagePercent = monthlyAllocation > 0
    ? Math.round(((monthlyAllocation - tokenBalance?.subscription_tokens || 0) / monthlyAllocation) * 100)
    : 0;
  return {
    subscription,
    tokenBalance,
    usageLimits,
    savings,
    isPremium: isPremium || (isTrial && !isTrialExpired),
    isTrial,
    isTrialExpired,
    daysUntilRenewal,
    daysUntilTrialEnd,
    totalTokens,
    tokenUsagePercent,
  };
}

/**
 * Check if a feature is accessible based on subscription tier
 */
export async function checkFeatureAccess(
  userId: string,
  feature: string
): Promise<FeatureAccessResult> {
  const { data, error } = await supabase.rpc('check_feature_access', {
    p_user_id: userId,
    p_feature: feature,
  });
  if (error) {
    console.error('Error checking feature access:', error);
    return { allowed: false, reason: 'Error checking access' };
  }
  return data as FeatureAccessResult;
}

/**
 * Check if user has enough tokens for a feature
 */
export async function checkTokenAvailability(
  userId: string,
  requiredTokens: number
): Promise<{ available: boolean; balance: number; required: number }> {
  const { data, error } = await supabase.rpc('get_available_tokens', {
    p_user_id: userId,
  });
  if (error) {
    console.error('Error checking token availability:', error);
    return { available: false, balance: 0, required: requiredTokens };
  }
  const balance = data as number;
  return {
    available: balance >= requiredTokens,
    balance,
    required: requiredTokens,
  };
}

/**
 * Create a Stripe Checkout session for subscription
 */
export async function createCheckoutSession(
  userId: string,
  params: CreateCheckoutParams
): Promise<{ url: string | null; error: string | null }> {
  const priceId = params.tier === 'premium_annual'
    ? STRIPE_PRODUCTS.premium_annual
    : STRIPE_PRODUCTS.premium_monthly;
  const { data, error } = await supabase.functions.invoke('create-checkout-session', {
    body: {
      userId,
      priceId,
      mode: 'subscription',
      successUrl: params.successUrl,
      cancelUrl: params.cancelUrl,
    },
  });
  if (error) {
    console.error('Error creating checkout session:', error);
    return { url: null, error: error.message };
  }
  return { url: data.url, error: null };
}

/**
 * Create a Stripe Checkout session for token bucket purchase
 */
export async function createTokenPurchaseSession(
  userId: string,
  params: CreateTokenPurchaseParams
): Promise<{ url: string | null; error: string | null }> {
  let priceId: string;
  switch (params.bucketSize) {
    case 50:
      priceId = STRIPE_PRODUCTS.tokens_50;
      break;
    case 150:
      priceId = STRIPE_PRODUCTS.tokens_150;
      break;
    case 400:
      priceId = STRIPE_PRODUCTS.tokens_400;
      break;
    default:
      return { url: null, error: 'Invalid bucket size' };
  }
  const { data, error } = await supabase.functions.invoke('create-checkout-session', {
    body: {
      userId,
      priceId,
      mode: 'payment',
      successUrl: params.successUrl,
      cancelUrl: params.cancelUrl,
      metadata: {
        type: 'token_purchase',
        bucket_size: params.bucketSize,
      },
    },
  });
  if (error) {
    console.error('Error creating token purchase session:', error);
    return { url: null, error: error.message };
  }
  return { url: data.url, error: null };
}

/**
 * Get Stripe Customer Portal URL for subscription management
 */
export async function getCustomerPortalUrl(
  userId: string,
  returnUrl: string
): Promise<{ url: string | null; error: string | null }> {
  const { data, error } = await supabase.functions.invoke('create-portal-session', {
    body: {
      userId,
      returnUrl,
    },
  });
  if (error) {
    console.error('Error creating portal session:', error);
    return { url: null, error: error.message };
  }
  return { url: data.url, error: null };
}

/**
 * Start a free trial
 */
export async function startFreeTrial(
  userId: string
): Promise<{ success: boolean; error: string | null }> {
  const { error } = await supabase.functions.invoke('start-free-trial', {
    body: { userId },
  });
  if (error) {
    console.error('Error starting free trial:', error);
    return { success: false, error: error.message };
  }
  return { success: true, error: null };
}

/**
 * Cancel subscription at period end
 */
export async function cancelSubscription(
  userId: string
): Promise<{ success: boolean; error: string | null }> {
  const { error } = await supabase.functions.invoke('cancel-subscription', {
    body: { userId },
  });
  if (error) {
    console.error('Error canceling subscription:', error);
    return { success: false, error: error.message };
  }
  return { success: true, error: null };
}

/**
 * Resume a canceled subscription
 */
export async function resumeSubscription(
  userId: string
): Promise<{ success: boolean; error: string | null }> {
  const { error } = await supabase.functions.invoke('resume-subscription', {
    body: { userId },
  });
  if (error) {
    console.error('Error resuming subscription:', error);
    return { success: false, error: error.message };
  }
  return { success: true, error: null };
}

/**
 * Get estimated savings for ROI messaging
 */
export async function getEstimatedSavings(
  userId: string,
  period: 'week' | 'month' | 'all_time' = 'month'
): Promise<{
  itemsSaved: number;
  moneySaved: number;
  co2Avoided: number;
}> {
  const { data, error } = await supabase
    .from('savings_tracking')
    .select('*')
    .eq('user_id', userId);
  if (error) {
    console.error('Error fetching savings:', error);
    return { itemsSaved: 0, moneySaved: 0, co2Avoided: 0 };
  }
  if (!data || data.length === 0) {
    return { itemsSaved: 0, moneySaved: 0, co2Avoided: 0 };
  }
  const now = new Date();
  let filteredData = data;
  if (period === 'week') {
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    filteredData = data.filter(d => new Date(d.month_start) >= weekAgo);
  } else if (period === 'month') {
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    filteredData = data.filter(d => new Date(d.month_start) >= monthStart);
  }
  const totals = filteredData.reduce(
    (acc, curr) => ({
      itemsSaved: acc.itemsSaved + curr.items_saved_from_waste,
      moneySaved: acc.moneySaved + curr.estimated_savings_cents / 100,
      co2Avoided: acc.co2Avoided + curr.co2_avoided_grams / 1000,
    }),
    { itemsSaved: 0, moneySaved: 0, co2Avoided: 0 }
  );
  return totals;
}

/**
 * Record savings event (for ROI tracking)
 */
export async function recordSavings(
  userId: string,
  data: {
    itemsSaved?: number;
    savingsCents?: number;
    co2Grams?: number;
    mealsPlanned?: number;
    recipesGenerated?: number;
  }
): Promise<void> {
  const currentMonth = new Date().toISOString().slice(0, 7) + '-01';
  const { error } = await supabase.rpc('upsert_savings_tracking', {
    p_user_id: userId,
    p_month_start: currentMonth,
    p_items_saved: data.itemsSaved || 0,
    p_savings_cents: data.savingsCents || 0,
    p_co2_grams: data.co2Grams || 0,
    p_meals_planned: data.mealsPlanned || 0,
    p_recipes_generated: data.recipesGenerated || 0,
  });
  if (error) {
    console.error('Error recording savings:', error);
  }
}

/**
 * Increment usage counter for free tier
 */
export async function incrementUsage(
  userId: string,
  usageType: 'pantry_items' | 'saved_recipes' | 'barcode_scans' | 'grocery_lists'
): Promise<void> {
  const currentMonth = new Date().toISOString().slice(0, 7) + '-01';
  const columnMap = {
    pantry_items: 'pantry_items_count',
    saved_recipes: 'saved_recipes_count',
    barcode_scans: 'barcode_scans_count',
    grocery_lists: 'grocery_lists_count',
  };
  const column = columnMap[usageType];
  // Upsert usage limits
  const { error } = await supabase.rpc('increment_usage_limit', {
    p_user_id: userId,
    p_period_start: currentMonth,
    p_column: column,
  });
  if (error) {
    console.error('Error incrementing usage:', error);
  }
}

/**
 * Get feature flags
 */
export async function getFeatureFlags(): Promise<Record<string, boolean>> {
  const { data, error } = await supabase
    .from('feature_flags')
    .select('name, enabled');
  if (error) {
    console.error('Error fetching feature flags:', error);
    return {};
  }
  return data.reduce((acc, flag) => {
    acc[flag.name] = flag.enabled;
    return acc;
  }, {} as Record<string, boolean>);
}

/**
 * Check if subscription system is enabled
 */
export async function isSubscriptionEnabled(): Promise<boolean> {
  const flags = await getFeatureFlags();
  return flags['subscriptions_enabled'] ?? false;
}

/**
 * Format price for display
 */
export function formatPrice(cents: number): string {
  return `$${(cents / 100).toFixed(2)}`;
}

/**
 * Get tier display name
 */
export function getTierDisplayName(tier: SubscriptionTier): string {
  switch (tier) {
    case 'free':
      return 'Free';
    case 'trial':
      return 'Trial';
    case 'premium_monthly':
      return 'Premium Monthly';
    case 'premium_annual':
      return 'Premium Annual';
    default:
      return tier;
  }
}

/**
 * Calculate days remaining in subscription period
 */
export function getDaysRemaining(endDate: string | null): number {
  if (!endDate) return 0;
  const end = new Date(endDate);
  const now = new Date();
  const diffTime = end.getTime() - now.getTime();
  return Math.max(0, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));
}

