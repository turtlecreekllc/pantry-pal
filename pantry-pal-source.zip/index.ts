/**
 * Start Free Trial
 * Supabase Edge Function to start a 14-day free trial
 */

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const TRIAL_DURATION_DAYS = 14;
const TRIAL_TOKENS = 100;

serve(async (req: Request) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }
  try {
    const { userId } = await req.json();
    if (!userId) {
      return new Response(
        JSON.stringify({ error: 'Missing userId' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    // Check if user already had a trial
    const { data: existingSub } = await supabase
      .from('subscriptions')
      .select('tier, trial_end')
      .eq('user_id', userId)
      .single();
    if (existingSub?.trial_end) {
      return new Response(
        JSON.stringify({ error: 'User already used trial' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    if (existingSub?.tier !== 'free') {
      return new Response(
        JSON.stringify({ error: 'User already has a subscription' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }
    // Calculate trial dates
    const trialStart = new Date();
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + TRIAL_DURATION_DAYS);
    // Update subscription to trial
    const { error: subError } = await supabase
      .from('subscriptions')
      .update({
        tier: 'trial',
        status: 'trialing',
        trial_start: trialStart.toISOString(),
        trial_end: trialEnd.toISOString(),
        current_period_start: trialStart.toISOString(),
        current_period_end: trialEnd.toISOString(),
        updated_at: new Date().toISOString(),
      })
      .eq('user_id', userId);
    if (subError) {
      throw new Error(`Failed to update subscription: ${subError.message}`);
    }
    // Grant trial tokens
    const { error: tokenError } = await supabase.rpc('grant_subscription_tokens', {
      p_user_id: userId,
      p_amount: TRIAL_TOKENS,
      p_is_annual: false,
    });
    if (tokenError) {
      console.error('Failed to grant tokens:', tokenError);
    }
    return new Response(
      JSON.stringify({
        success: true,
        trialEnd: trialEnd.toISOString(),
        tokensGranted: TRIAL_TOKENS,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (err) {
    console.error('Error starting trial:', err);
    return new Response(
      JSON.stringify({ error: err.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

