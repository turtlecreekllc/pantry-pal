/**
 * Custom hook for Siri Shortcuts integration
 *
 * This hook handles:
 * - Suggesting shortcuts on first app launch
 * - Listening for shortcut activations
 * - Handling initial shortcut if app was launched from one
 *
 * @module useSiriShortcuts
 */

import { useEffect, useRef } from 'react';
import { Platform } from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  suggestAllShortcuts,
  getInitialShortcut,
  addShortcutListener,
  handleSiriShortcut,
} from '../lib/siriShortcuts';

const SHORTCUTS_SUGGESTED_KEY = '@dinnerplans/siri_shortcuts_suggested';

/**
 * Hook to initialize and manage Siri Shortcuts
 * Call this in your app's root layout component
 */
export function useSiriShortcuts(): void {
  const router = useRouter();
  const listenerRef = useRef<{ remove: () => void } | null>(null);

  useEffect(() => {
    if (Platform.OS !== 'ios') return;

    const initializeSiriShortcuts = async (): Promise<void> => {
      try {
        // Check if we've already suggested shortcuts
        const alreadySuggested = await AsyncStorage.getItem(SHORTCUTS_SUGGESTED_KEY);
        if (!alreadySuggested) {
          // First launch - suggest all shortcuts to Siri
          await suggestAllShortcuts();
          await AsyncStorage.setItem(SHORTCUTS_SUGGESTED_KEY, 'true');
        }
        // Check if app was launched from a shortcut
        const initialShortcut = await getInitialShortcut();
        if (initialShortcut) {
          // Small delay to ensure navigation is ready
          setTimeout(() => {
            handleSiriShortcut(
              initialShortcut.activityType,
              initialShortcut.userInfo,
              router
            );
          }, 100);
        }
        // Listen for shortcut activations while app is running
        listenerRef.current = addShortcutListener(({ activityType, userInfo }) => {
          handleSiriShortcut(activityType, userInfo, router);
        });
      } catch (error) {
        console.error('Error initializing Siri shortcuts:', error);
      }
    };

    initializeSiriShortcuts();
    return () => {
      if (listenerRef.current) {
        listenerRef.current.remove();
      }
    };
  }, [router]);
}

/**
 * Hook to donate a shortcut after user performs an action
 * This makes the action appear in Siri suggestions
 */
export { donateShortcutToSiri } from '../lib/siriShortcuts';

