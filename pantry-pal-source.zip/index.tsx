/**
 * Onboarding Screen
 * Welcome and plan selection following PRD specifications
 */

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Animated,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSubscription, PLAN_PRICING } from '../../hooks/useSubscription';
import { Button } from '../../components/ui/Button';

type OnboardingStep = 'welcome' | 'plan' | 'trial' | 'quick-start';

export default function OnboardingScreen() {
  const router = useRouter();
  const { openCheckout, startTrial, isPremium, isTrial } = useSubscription();
  const [step, setStep] = useState<OnboardingStep>('welcome');
  const [selectedPlan, setSelectedPlan] = useState<'monthly' | 'annual'>('annual');
  const fadeAnim = useState(new Animated.Value(0))[0];
  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();
  }, [step, fadeAnim]);
  // Skip onboarding if already subscribed
  useEffect(() => {
    if (isPremium || isTrial) {
      router.replace('/(tabs)');
    }
  }, [isPremium, isTrial, router]);
  const handleStartPremium = async () => {
    await openCheckout(selectedPlan === 'annual' ? 'premium_annual' : 'premium_monthly');
  };
  const handleStartTrial = async () => {
    const result = await startTrial();
    if (result.success) {
      setStep('quick-start');
    } else {
      Alert.alert('Error', result.error || 'Failed to start trial');
    }
  };
  const handleSkipToFree = () => {
    router.replace('/(tabs)');
  };
  const handleFinishOnboarding = () => {
    router.replace('/(tabs)');
  };
  const renderWelcomeStep = () => (
    <Animated.View style={[styles.stepContainer, { opacity: fadeAnim }]}>
      <View style={styles.heroSection}>
        <View style={styles.heroIcon}>
          <Ionicons name="leaf" size={64} color="#4CAF50" />
        </View>
        <Text style={styles.heroTitle}>Stop wasting food.</Text>
        <Text style={styles.heroTitle}>Start saving money.</Text>
        <Text style={styles.heroSubtitle}>
          Families save $100+ per month with smarter meal planning
        </Text>
      </View>
      <View style={styles.socialProof}>
        <View style={styles.socialProofStars}>
          {[1, 2, 3, 4, 5].map(i => (
            <Ionicons key={i} name="star" size={20} color="#FFD700" />
          ))}
        </View>
        <Text style={styles.socialProofText}>
          Join 10,000+ families who've cut their grocery bills
        </Text>
      </View>
      <Button
        title="Start Saving Today"
        onPress={() => setStep('plan')}
        style={styles.primaryButton}
      />
    </Animated.View>
  );
  const renderPlanStep = () => (
    <Animated.View style={[styles.stepContainer, { opacity: fadeAnim }]}>
      <Text style={styles.stepTitle}>Choose Your Plan</Text>
      {/* Premium Card - Recommended */}
      <View style={styles.planCardsContainer}>
        <TouchableOpacity
          style={[styles.planCard, styles.planCardRecommended]}
          onPress={() => setSelectedPlan('annual')}
        >
          <View style={styles.recommendedBadge}>
            <Text style={styles.recommendedBadgeText}>RECOMMENDED</Text>
          </View>
          <View style={styles.planToggle}>
            <TouchableOpacity
              style={[
                styles.toggleOption,
                selectedPlan === 'monthly' && styles.toggleOptionActive,
              ]}
              onPress={() => setSelectedPlan('monthly')}
            >
              <Text
                style={[
                  styles.toggleText,
                  selectedPlan === 'monthly' && styles.toggleTextActive,
                ]}
              >
                Monthly
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.toggleOption,
                selectedPlan === 'annual' && styles.toggleOptionActive,
              ]}
              onPress={() => setSelectedPlan('annual')}
            >
              <Text
                style={[
                  styles.toggleText,
                  selectedPlan === 'annual' && styles.toggleTextActive,
                ]}
              >
                Annual
              </Text>
              <Text style={styles.saveBadge}>Save 18%</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.planPrice}>
            {selectedPlan === 'annual'
              ? PLAN_PRICING.premium_annual.monthlyEquivalent
              : PLAN_PRICING.premium_monthly.displayPrice}
          </Text>
          <Text style={styles.planPeriod}>
            {selectedPlan === 'annual' ? 'per month, billed annually' : 'per month'}
          </Text>
          {/* ROI Callout */}
          <View style={styles.roiCallout}>
            <Ionicons name="cash-outline" size={18} color="#4CAF50" />
            <Text style={styles.roiText}>
              Pays for itself after saving just ONE ingredient from the trash
            </Text>
          </View>
          {/* Feature List */}
          <View style={styles.featureList}>
            {[
              'AI meal planning (100 tokens/mo)',
              'Unlimited pantry tracking',
              'Household sharing (6 members)',
              'Full nutrition tracking',
              'Ad-free experience',
            ].map((feature, index) => (
              <View key={index} style={styles.featureItem}>
                <Ionicons name="checkmark-circle" size={18} color="#4CAF50" />
                <Text style={styles.featureText}>{feature}</Text>
              </View>
            ))}
          </View>
          {/* Savings Calculator Mini */}
          <View style={styles.savingsCalculator}>
            <Ionicons name="trending-up" size={20} color="#2E7D32" />
            <Text style={styles.savingsText}>
              Average family saves: $127/month
            </Text>
          </View>
          <Button
            title="Start Premium"
            onPress={handleStartPremium}
            style={styles.premiumButton}
          />
        </TouchableOpacity>
      </View>
      {/* Free Trial Option */}
      <TouchableOpacity style={styles.trialOption} onPress={handleStartTrial}>
        <Text style={styles.trialTitle}>Not sure? Try Premium free for 14 days</Text>
        <Text style={styles.trialSubtitle}>No credit card required</Text>
      </TouchableOpacity>
      {/* Free Tier Link */}
      <TouchableOpacity style={styles.freeLink} onPress={handleSkipToFree}>
        <Text style={styles.freeLinkText}>
          Or continue with limited free version
        </Text>
      </TouchableOpacity>
    </Animated.View>
  );
  const renderTrialStep = () => (
    <Animated.View style={[styles.stepContainer, { opacity: fadeAnim }]}>
      <View style={styles.trialHero}>
        <View style={styles.countdownCircle}>
          <Text style={styles.countdownNumber}>14</Text>
          <Text style={styles.countdownLabel}>days</Text>
        </View>
        <Text style={styles.trialHeroTitle}>Your Premium Trial Starts Now!</Text>
        <Text style={styles.trialHeroSubtitle}>
          Full Premium access for 14 days, no credit card needed
        </Text>
      </View>
      {/* What you'll get */}
      <View style={styles.trialFeatures}>
        <Text style={styles.trialFeaturesTitle}>What you'll get to try:</Text>
        {[
          { icon: 'sparkles', text: '100 AI tokens for smart meal planning' },
          { icon: 'infinite', text: 'Unlimited pantry & recipe storage' },
          { icon: 'people', text: 'Share with up to 6 household members' },
          { icon: 'analytics', text: 'Full nutritional information' },
        ].map((feature, index) => (
          <View key={index} style={styles.trialFeatureItem}>
            <Ionicons name={feature.icon as any} size={24} color="#4CAF50" />
            <Text style={styles.trialFeatureText}>{feature.text}</Text>
          </View>
        ))}
      </View>
      {/* Reminder Note */}
      <View style={styles.reminderNote}>
        <Ionicons name="notifications-outline" size={20} color="#666" />
        <Text style={styles.reminderText}>
          We'll notify you 3 days before your trial ends
        </Text>
      </View>
      <Button
        title="Let's Get Started"
        onPress={() => setStep('quick-start')}
        style={styles.primaryButton}
      />
    </Animated.View>
  );
  const renderQuickStartStep = () => (
    <Animated.View style={[styles.stepContainer, { opacity: fadeAnim }]}>
      <View style={styles.quickStartHero}>
        <Ionicons name="rocket" size={64} color="#4CAF50" />
        <Text style={styles.quickStartTitle}>Let's stock your pantry!</Text>
        <Text style={styles.quickStartSubtitle}>
          A quick 3-step setup to start saving money
        </Text>
      </View>
      {/* Progress Steps */}
      <View style={styles.quickStartSteps}>
        {[
          { icon: 'barcode', title: 'Scan your first item', description: 'Use barcode or photo scanning' },
          { icon: 'calendar', title: 'Plan a meal', description: 'Let AI suggest based on what you have' },
          { icon: 'cart', title: 'Generate grocery list', description: 'Smart lists organized by aisle' },
        ].map((stepItem, index) => (
          <View key={index} style={styles.quickStartStep}>
            <View style={styles.quickStartStepNumber}>
              <Text style={styles.quickStartStepNumberText}>{index + 1}</Text>
            </View>
            <View style={styles.quickStartStepIcon}>
              <Ionicons name={stepItem.icon as any} size={24} color="#4CAF50" />
            </View>
            <View style={styles.quickStartStepContent}>
              <Text style={styles.quickStartStepTitle}>{stepItem.title}</Text>
              <Text style={styles.quickStartStepDescription}>{stepItem.description}</Text>
            </View>
          </View>
        ))}
      </View>
      <Button
        title="Start Adding Items"
        onPress={handleFinishOnboarding}
        style={styles.primaryButton}
      />
      <TouchableOpacity style={styles.skipButton} onPress={handleFinishOnboarding}>
        <Text style={styles.skipButtonText}>Skip for now</Text>
      </TouchableOpacity>
    </Animated.View>
  );
  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      {step === 'welcome' && renderWelcomeStep()}
      {step === 'plan' && renderPlanStep()}
      {step === 'trial' && renderTrialStep()}
      {step === 'quick-start' && renderQuickStartStep()}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  content: {
    flexGrow: 1,
    padding: 24,
    paddingTop: 60,
  },
  stepContainer: {
    flex: 1,
  },
  // Welcome Step
  heroSection: {
    alignItems: 'center',
    marginBottom: 32,
  },
  heroIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  heroTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#333',
    textAlign: 'center',
  },
  heroSubtitle: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 24,
  },
  socialProof: {
    alignItems: 'center',
    marginBottom: 32,
  },
  socialProofStars: {
    flexDirection: 'row',
    marginBottom: 8,
  },
  socialProofText: {
    fontSize: 14,
    color: '#666',
  },
  primaryButton: {
    marginTop: 16,
  },
  // Plan Step
  stepTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    textAlign: 'center',
    marginBottom: 24,
  },
  planCardsContainer: {
    marginBottom: 24,
  },
  planCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 24,
    borderWidth: 2,
    borderColor: '#4CAF50',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  planCardRecommended: {
    borderColor: '#4CAF50',
  },
  recommendedBadge: {
    position: 'absolute',
    top: -12,
    left: '50%',
    marginLeft: -60,
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
  },
  recommendedBadgeText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#fff',
  },
  planToggle: {
    flexDirection: 'row',
    backgroundColor: '#f5f5f5',
    borderRadius: 10,
    padding: 4,
    marginTop: 12,
    marginBottom: 16,
  },
  toggleOption: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    position: 'relative',
  },
  toggleOptionActive: {
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
  },
  toggleText: {
    fontSize: 14,
    color: '#666',
  },
  toggleTextActive: {
    color: '#4CAF50',
    fontWeight: '600',
  },
  saveBadge: {
    position: 'absolute',
    top: -8,
    right: 10,
    fontSize: 9,
    fontWeight: '700',
    color: '#fff',
    backgroundColor: '#FF9800',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
  },
  planPrice: {
    fontSize: 40,
    fontWeight: '700',
    color: '#4CAF50',
    textAlign: 'center',
  },
  planPeriod: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginBottom: 16,
  },
  roiCallout: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#E8F5E9',
    padding: 12,
    borderRadius: 10,
    marginBottom: 16,
  },
  roiText: {
    flex: 1,
    fontSize: 13,
    color: '#2E7D32',
    marginLeft: 8,
  },
  featureList: {
    marginBottom: 16,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  featureText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 10,
  },
  savingsCalculator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FFF8E1',
    padding: 12,
    borderRadius: 10,
    marginBottom: 16,
  },
  savingsText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#F9A825',
    marginLeft: 8,
  },
  premiumButton: {
    backgroundColor: '#4CAF50',
  },
  trialOption: {
    alignItems: 'center',
    paddingVertical: 20,
    borderTopWidth: 1,
    borderTopColor: '#f0f0f0',
  },
  trialTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#4CAF50',
  },
  trialSubtitle: {
    fontSize: 13,
    color: '#999',
    marginTop: 4,
  },
  freeLink: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  freeLinkText: {
    fontSize: 14,
    color: '#999',
    textDecorationLine: 'underline',
  },
  // Trial Step
  trialHero: {
    alignItems: 'center',
    marginBottom: 32,
  },
  countdownCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  countdownNumber: {
    fontSize: 40,
    fontWeight: '700',
    color: '#4CAF50',
  },
  countdownLabel: {
    fontSize: 14,
    color: '#4CAF50',
  },
  trialHeroTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    textAlign: 'center',
  },
  trialHeroSubtitle: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
    marginTop: 8,
  },
  trialFeatures: {
    marginBottom: 24,
  },
  trialFeaturesTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 16,
  },
  trialFeatureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
    padding: 16,
    borderRadius: 12,
    marginBottom: 8,
  },
  trialFeatureText: {
    fontSize: 14,
    color: '#333',
    marginLeft: 12,
    flex: 1,
  },
  reminderNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  reminderText: {
    fontSize: 13,
    color: '#666',
    marginLeft: 8,
  },
  // Quick Start Step
  quickStartHero: {
    alignItems: 'center',
    marginBottom: 32,
  },
  quickStartTitle: {
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    marginTop: 16,
  },
  quickStartSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 8,
  },
  quickStartSteps: {
    marginBottom: 24,
  },
  quickStartStep: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 4,
    elevation: 2,
  },
  quickStartStepNumber: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: '#E8F5E9',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  quickStartStepNumberText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#4CAF50',
  },
  quickStartStepIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#f5f5f5',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  quickStartStepContent: {
    flex: 1,
  },
  quickStartStepTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  quickStartStepDescription: {
    fontSize: 13,
    color: '#666',
    marginTop: 2,
  },
  skipButton: {
    alignItems: 'center',
    paddingVertical: 16,
  },
  skipButtonText: {
    fontSize: 14,
    color: '#999',
  },
});

