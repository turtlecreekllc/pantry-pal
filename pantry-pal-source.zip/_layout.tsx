import { useEffect, useState, useCallback } from 'react';
import { View, StyleSheet } from 'react-native';
import { Stack, router } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../context/AuthContext';
import { HealthProvider } from '../context/HealthContext';
import { HouseholdProvider } from '../context/HouseholdContext';
import { SubscriptionProvider } from '../context/SubscriptionContext';
import * as SplashScreen from 'expo-splash-screen';
import * as Linking from 'expo-linking';
import * as Font from 'expo-font';
import { useShareIntent } from 'expo-share-intent';
import { handleSharedContent, subscribeToIncomingLinks, handleShareIntent } from '../lib/shareReceiver';
import { useSiriShortcuts } from '../hooks/useSiriShortcuts';
import { colors } from '../lib/theme';
import {
  Nunito_400Regular,
  Nunito_500Medium,
  Nunito_600SemiBold,
  Nunito_700Bold,
} from '@expo-google-fonts/nunito';
import {
  Quicksand_400Regular,
  Quicksand_500Medium,
  Quicksand_600SemiBold,
  Quicksand_700Bold,
} from '@expo-google-fonts/quicksand';

// Safely prevent auto-hide with error handling
try {
  SplashScreen.preventAutoHideAsync();
} catch (e) {
  console.warn('SplashScreen.preventAutoHideAsync error:', e);
}

export default function RootLayout(): React.ReactElement | null {
  const [appIsReady, setAppIsReady] = useState(false);
  const { shareIntent, resetShareIntent, hasShareIntent } = useShareIntent();

  // Initialize Siri Shortcuts integration (iOS only)
  useSiriShortcuts();

  // Handle incoming shared content from URL scheme
  const handleIncomingUrl = useCallback(async (url: string) => {
    console.log('Received URL:', url);
    await handleSharedContent(url);
  }, []);

  // Handle share intent from native share extension
  useEffect(() => {
    if (hasShareIntent && shareIntent && appIsReady) {
      console.log('Share intent received:', shareIntent);
      handleShareIntent(shareIntent).then((handled) => {
        if (handled) {
          resetShareIntent();
        }
      });
    }
  }, [hasShareIntent, shareIntent, appIsReady, resetShareIntent]);

  useEffect(() => {
    async function prepare(): Promise<void> {
      try {
        // Load brand fonts
        await Font.loadAsync({
          'Nunito-Regular': Nunito_400Regular,
          'Nunito-Medium': Nunito_500Medium,
          'Nunito-SemiBold': Nunito_600SemiBold,
          'Nunito-Bold': Nunito_700Bold,
          'Quicksand-Regular': Quicksand_400Regular,
          'Quicksand-Medium': Quicksand_500Medium,
          'Quicksand-SemiBold': Quicksand_600SemiBold,
          'Quicksand-Bold': Quicksand_700Bold,
        });
        // Perform any initial loading tasks here
        await new Promise(resolve => setTimeout(resolve, 500));
        // Check if app was opened with a shared URL - wrapped in try-catch
        try {
          const initialUrl = await Linking.getInitialURL();
          if (initialUrl) {
            // Delay handling to ensure navigation is ready
            setTimeout(() => handleIncomingUrl(initialUrl), 1000);
          }
        } catch (linkingError) {
          console.warn('Linking.getInitialURL error:', linkingError);
        }
      } catch (e) {
        console.warn('Prepare error:', e);
      } finally {
        setAppIsReady(true);
        try {
          await SplashScreen.hideAsync();
        } catch (splashError) {
          console.warn('SplashScreen.hideAsync error:', splashError);
        }
      }
    }
    prepare();
  }, [handleIncomingUrl]);

  // Subscribe to incoming links while app is running
  useEffect(() => {
    const unsubscribe = subscribeToIncomingLinks(handleIncomingUrl);
    return unsubscribe;
  }, [handleIncomingUrl]);

  if (!appIsReady) {
    return null;
  }

  return (
    <AuthProvider>
      <SubscriptionProvider>
        <HouseholdProvider>
          <HealthProvider>
            <View style={styles.container}>
              <StatusBar style="dark" />
              <Stack screenOptions={{ headerShown: false }}>
                <Stack.Screen name="(auth)" options={{ headerShown: false }} />
                <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
                <Stack.Screen name="item" options={{ headerShown: false }} />
                <Stack.Screen name="recipe" options={{ headerShown: false }} />
                <Stack.Screen name="onboarding" options={{ headerShown: false }} />
                <Stack.Screen name="settings" options={{ headerShown: false }} />
                <Stack.Screen
                  name="share-receiver"
                  options={{
                    headerShown: true,
                    title: 'Import Recipe',
                    presentation: 'modal',
                  }}
                />
              </Stack>
            </View>
          </HealthProvider>
        </HouseholdProvider>
      </SubscriptionProvider>
    </AuthProvider>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.cream,
  },
});
