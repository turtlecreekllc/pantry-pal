import React, { useState } from 'react';
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { Platform, TouchableOpacity, View, StyleSheet } from 'react-native';
import { SettingsMenu } from '../../components/SettingsMenu';
import { colors, typography, spacing, borderRadius } from '../../lib/theme';

export default function TabLayout(): React.ReactElement {
  const [showSettings, setShowSettings] = useState(false);

  return (
    <>
      <Tabs
        screenOptions={{
          tabBarActiveTintColor: colors.brown,
          tabBarInactiveTintColor: colors.brownMuted,
          tabBarStyle: {
            backgroundColor: colors.white,
            borderTopColor: colors.brown,
            borderTopWidth: 2,
            paddingTop: spacing.space2,
            height: Platform.OS === 'ios' ? 88 : 68,
          },
          tabBarLabelStyle: {
            fontFamily: 'Nunito-Medium',
            fontSize: typography.textXs,
            fontWeight: typography.fontMedium,
          },
          tabBarIconStyle: {
            marginTop: spacing.space1,
          },
          headerStyle: {
            backgroundColor: colors.primary,
            borderBottomWidth: 2,
            borderBottomColor: colors.brown,
          },
          headerTintColor: colors.brown,
          headerTitleStyle: {
            fontFamily: 'Quicksand-Bold',
            fontWeight: typography.fontBold,
            fontSize: typography.textLg,
            color: colors.brown,
          },
          headerShadowVisible: false,
          headerLeft: () => (
            <TouchableOpacity
              onPress={() => setShowSettings(true)}
              style={styles.menuButton}
              accessibilityLabel="Open settings menu"
              accessibilityRole="button"
            >
              <Ionicons name="menu" size={24} color={colors.brown} />
            </TouchableOpacity>
          ),
        }}
      >
        <Tabs.Screen
          name="index"
          options={{
            title: 'DinnerPlans',
            tabBarLabel: 'Pantry',
            tabBarIcon: ({ color, focused }) => (
              <View style={[styles.tabIcon, focused && styles.tabIconActive]}>
                <Ionicons name="home" size={22} color={focused ? colors.brown : color} />
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="recipes"
          options={{
            title: 'Recipes',
            tabBarIcon: ({ color, focused }) => (
              <View style={[styles.tabIcon, focused && styles.tabIconActive]}>
                <Ionicons name="book" size={22} color={focused ? colors.brown : color} />
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="calendar"
          options={{
            title: 'Calendar',
            tabBarIcon: ({ color, focused }) => (
              <View style={[styles.tabIcon, focused && styles.tabIconActive]}>
                <Ionicons name="calendar" size={22} color={focused ? colors.brown : color} />
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="chat"
          options={{
            title: 'Chat',
            tabBarIcon: ({ color, focused }) => (
              <View style={[styles.tabIcon, focused && styles.tabIconActive]}>
                <Ionicons name="chatbubbles" size={22} color={focused ? colors.brown : color} />
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="grocery"
          options={{
            title: 'Grocery',
            tabBarIcon: ({ color, focused }) => (
              <View style={[styles.tabIcon, focused && styles.tabIconActive]}>
                <Ionicons name="cart" size={22} color={focused ? colors.brown : color} />
              </View>
            ),
          }}
        />
        <Tabs.Screen
          name="saved"
          options={{
            title: 'Saved',
            tabBarIcon: ({ color, focused }) => (
              <View style={[styles.tabIcon, focused && styles.tabIconActive]}>
                <Ionicons name="heart" size={22} color={focused ? colors.brown : color} />
              </View>
            ),
            tabBarItemStyle: { display: 'none' },
          }}
        />
        <Tabs.Screen
          name="scan"
          options={{
            title: 'Scan',
            tabBarIcon: ({ color, focused }) => (
              <View style={[styles.tabIcon, focused && styles.tabIconActive]}>
                <Ionicons name="scan" size={22} color={focused ? colors.brown : color} />
              </View>
            ),
            headerShown: false,
            tabBarItemStyle: { display: 'none' },
          }}
        />
      </Tabs>

      <SettingsMenu visible={showSettings} onClose={() => setShowSettings(false)} />
    </>
  );
}

const styles = StyleSheet.create({
  menuButton: {
    marginLeft: spacing.space4,
    padding: spacing.space1,
    borderRadius: borderRadius.sm,
  },
  tabIcon: {
    width: 36,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: borderRadius.full,
  },
  tabIconActive: {
    backgroundColor: colors.primary,
  },
});
