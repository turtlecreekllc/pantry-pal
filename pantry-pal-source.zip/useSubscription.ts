/**
 * useSubscription Hook
 * React hook for managing subscription state and operations
 */

import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  SubscriptionState,
  TokenTransaction,
  AIFeatureType,
  FeatureAccessResult,
  TOKEN_COSTS,
  PLAN_PRICING,
  TOKEN_BUCKETS,
  FREE_TIER_LIMITS,
} from '../lib/types';
import * as subscriptionService from '../lib/subscriptionService';
import * as tokenService from '../lib/tokenService';

interface UseSubscriptionReturn {
  // State
  state: SubscriptionState | null;
  loading: boolean;
  error: string | null;
  // Subscription info
  isPremium: boolean;
  isTrial: boolean;
  isTrialExpired: boolean;
  tier: string;
  daysUntilRenewal: number | null;
  daysUntilTrialEnd: number | null;
  // Token info
  totalTokens: number;
  tokenUsagePercent: number;
  subscriptionTokens: number;
  purchasedTokens: number;
  rolloverTokens: number;
  // Actions
  refresh: () => Promise<void>;
  checkFeatureAccess: (feature: string) => Promise<FeatureAccessResult>;
  hasEnoughTokens: (featureType: AIFeatureType) => Promise<boolean>;
  consumeTokens: (featureType: AIFeatureType, description?: string) => Promise<boolean>;
  startTrial: () => Promise<{ success: boolean; error?: string }>;
  openCheckout: (tier: 'premium_monthly' | 'premium_annual') => Promise<void>;
  openTokenPurchase: (bucketSize: 50 | 150 | 400) => Promise<void>;
  openCustomerPortal: () => Promise<void>;
  cancelSubscription: () => Promise<{ success: boolean; error?: string }>;
  resumeSubscription: () => Promise<{ success: boolean; error?: string }>;
  // Token history
  getTokenHistory: (limit?: number) => Promise<TokenTransaction[]>;
  getTokenStats: (days?: number) => Promise<{
    totalUsed: number;
    byFeature: Record<AIFeatureType, number>;
    dailyUsage: { date: string; tokens: number }[];
  }>;
  // Savings
  getSavings: (period?: 'week' | 'month' | 'all_time') => Promise<{
    itemsSaved: number;
    moneySaved: number;
    co2Avoided: number;
  }>;
  // Utils
  getTokenCost: (featureType: AIFeatureType) => number;
  formatPrice: (cents: number) => string;
}

/**
 * Hook for managing subscription state and operations
 */
export function useSubscription(): UseSubscriptionReturn {
  const { user } = useAuth();
  const [state, setState] = useState<SubscriptionState | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  /**
   * Fetch subscription state
   */
  const refresh = useCallback(async () => {
    if (!user?.id) {
      setState(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    setError(null);
    try {
      const subscriptionState = await subscriptionService.getSubscriptionState(user.id);
      setState(subscriptionState);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load subscription');
    } finally {
      setLoading(false);
    }
  }, [user?.id]);
  // Initial load
  useEffect(() => {
    refresh();
  }, [refresh]);
  /**
   * Check if a feature is accessible
   */
  const checkFeatureAccess = useCallback(
    async (feature: string): Promise<FeatureAccessResult> => {
      if (!user?.id) {
        return { allowed: false, reason: 'Not authenticated' };
      }
      return subscriptionService.checkFeatureAccess(user.id, feature);
    },
    [user?.id]
  );
  /**
   * Check if user has enough tokens for a feature
   */
  const hasEnoughTokens = useCallback(
    async (featureType: AIFeatureType): Promise<boolean> => {
      if (!user?.id) return false;
      return tokenService.hasEnoughTokens(user.id, featureType);
    },
    [user?.id]
  );
  /**
   * Consume tokens for a feature
   */
  const consumeTokens = useCallback(
    async (featureType: AIFeatureType, description?: string): Promise<boolean> => {
      if (!user?.id) return false;
      const result = await tokenService.consumeTokens(user.id, featureType, description);
      if (result.success) {
        // Refresh state to update token balance
        await refresh();
      }
      return result.success;
    },
    [user?.id, refresh]
  );
  /**
   * Start free trial
   */
  const startTrial = useCallback(async (): Promise<{ success: boolean; error?: string }> => {
    if (!user?.id) {
      return { success: false, error: 'Not authenticated' };
    }
    const result = await subscriptionService.startFreeTrial(user.id);
    if (result.success) {
      await refresh();
    }
    return result;
  }, [user?.id, refresh]);
  /**
   * Open Stripe Checkout for subscription
   */
  const openCheckout = useCallback(
    async (tier: 'premium_monthly' | 'premium_annual'): Promise<void> => {
      if (!user?.id) return;
      // Use deep linking URLs for mobile app
      const successUrl = 'dinnerplans://subscription/success';
      const cancelUrl = 'dinnerplans://subscription/cancel';
      const result = await subscriptionService.createCheckoutSession(user.id, {
        tier,
        successUrl,
        cancelUrl,
      });
      if (result.url) {
        // Open in browser using expo-web-browser
        const { openBrowserAsync } = await import('expo-web-browser');
        await openBrowserAsync(result.url);
      }
    },
    [user?.id]
  );
  /**
   * Open Stripe Checkout for token purchase
   */
  const openTokenPurchase = useCallback(
    async (bucketSize: 50 | 150 | 400): Promise<void> => {
      if (!user?.id) return;
      const successUrl = 'dinnerplans://tokens/success';
      const cancelUrl = 'dinnerplans://tokens/cancel';
      const result = await subscriptionService.createTokenPurchaseSession(user.id, {
        bucketSize,
        successUrl,
        cancelUrl,
      });
      if (result.url) {
        const { openBrowserAsync } = await import('expo-web-browser');
        await openBrowserAsync(result.url);
      }
    },
    [user?.id]
  );
  /**
   * Open Stripe Customer Portal
   */
  const openCustomerPortal = useCallback(async (): Promise<void> => {
    if (!user?.id) return;
    const returnUrl = 'dinnerplans://settings/subscription';
    const result = await subscriptionService.getCustomerPortalUrl(user.id, returnUrl);
    if (result.url) {
      const { openBrowserAsync } = await import('expo-web-browser');
      await openBrowserAsync(result.url);
    }
  }, [user?.id]);
  /**
   * Cancel subscription
   */
  const cancelSubscription = useCallback(async (): Promise<{ success: boolean; error?: string }> => {
    if (!user?.id) {
      return { success: false, error: 'Not authenticated' };
    }
    const result = await subscriptionService.cancelSubscription(user.id);
    if (result.success) {
      await refresh();
    }
    return result;
  }, [user?.id, refresh]);
  /**
   * Resume canceled subscription
   */
  const resumeSubscription = useCallback(async (): Promise<{ success: boolean; error?: string }> => {
    if (!user?.id) {
      return { success: false, error: 'Not authenticated' };
    }
    const result = await subscriptionService.resumeSubscription(user.id);
    if (result.success) {
      await refresh();
    }
    return result;
  }, [user?.id, refresh]);
  /**
   * Get token transaction history
   */
  const getTokenHistory = useCallback(
    async (limit: number = 20): Promise<TokenTransaction[]> => {
      if (!user?.id) return [];
      return tokenService.getRecentTransactions(user.id, limit);
    },
    [user?.id]
  );
  /**
   * Get token usage statistics
   */
  const getTokenStats = useCallback(
    async (days: number = 30) => {
      if (!user?.id) {
        return { totalUsed: 0, byFeature: {} as Record<AIFeatureType, number>, dailyUsage: [] };
      }
      return tokenService.getTokenUsageStats(user.id, days);
    },
    [user?.id]
  );
  /**
   * Get savings data for ROI messaging
   */
  const getSavings = useCallback(
    async (period: 'week' | 'month' | 'all_time' = 'month') => {
      if (!user?.id) {
        return { itemsSaved: 0, moneySaved: 0, co2Avoided: 0 };
      }
      return subscriptionService.getEstimatedSavings(user.id, period);
    },
    [user?.id]
  );
  /**
   * Get token cost for a feature
   */
  const getTokenCost = useCallback((featureType: AIFeatureType): number => {
    return TOKEN_COSTS[featureType];
  }, []);
  /**
   * Format price in cents to display string
   */
  const formatPrice = useCallback((cents: number): string => {
    return subscriptionService.formatPrice(cents);
  }, []);
  // Derived values
  const isPremium = state?.isPremium ?? false;
  const isTrial = state?.isTrial ?? false;
  const isTrialExpired = state?.isTrialExpired ?? false;
  const tier = state?.subscription?.tier ?? 'free';
  const daysUntilRenewal = state?.daysUntilRenewal ?? null;
  const daysUntilTrialEnd = state?.daysUntilTrialEnd ?? null;
  const totalTokens = state?.totalTokens ?? 0;
  const tokenUsagePercent = state?.tokenUsagePercent ?? 0;
  const subscriptionTokens = state?.tokenBalance?.subscription_tokens ?? 0;
  const purchasedTokens = state?.tokenBalance?.purchased_tokens ?? 0;
  const rolloverTokens = state?.tokenBalance?.rollover_tokens ?? 0;
  return {
    state,
    loading,
    error,
    isPremium,
    isTrial,
    isTrialExpired,
    tier,
    daysUntilRenewal,
    daysUntilTrialEnd,
    totalTokens,
    tokenUsagePercent,
    subscriptionTokens,
    purchasedTokens,
    rolloverTokens,
    refresh,
    checkFeatureAccess,
    hasEnoughTokens,
    consumeTokens,
    startTrial,
    openCheckout,
    openTokenPurchase,
    openCustomerPortal,
    cancelSubscription,
    resumeSubscription,
    getTokenHistory,
    getTokenStats,
    getSavings,
    getTokenCost,
    formatPrice,
  };
}

/**
 * Hook to check if a specific feature is accessible
 */
export function useFeatureAccess(feature: string) {
  const { user } = useAuth();
  const [access, setAccess] = useState<FeatureAccessResult>({ allowed: true });
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!user?.id) {
      setAccess({ allowed: false, reason: 'Not authenticated' });
      setLoading(false);
      return;
    }
    subscriptionService.checkFeatureAccess(user.id, feature).then(result => {
      setAccess(result);
      setLoading(false);
    });
  }, [user?.id, feature]);
  return { ...access, loading };
}

/**
 * Hook to check token availability for a feature
 */
export function useTokenAvailability(featureType: AIFeatureType) {
  const { user } = useAuth();
  const [available, setAvailable] = useState(false);
  const [balance, setBalance] = useState(0);
  const [loading, setLoading] = useState(true);
  const cost = TOKEN_COSTS[featureType];
  useEffect(() => {
    if (!user?.id) {
      setAvailable(false);
      setLoading(false);
      return;
    }
    tokenService.getTokenBalance(user.id).then(result => {
      setBalance(result.total);
      setAvailable(result.total >= cost);
      setLoading(false);
    });
  }, [user?.id, cost]);
  return { available, balance, cost, loading };
}

export { PLAN_PRICING, TOKEN_BUCKETS, FREE_TIER_LIMITS };

