import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  TextInput,
  Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../../components/ui/Button';

interface FAQItem {
  question: string;
  answer: string;
}

const FAQ_ITEMS: FAQItem[] = [
  {
    question: 'How do I scan items into my pantry?',
    answer:
      'Tap the scan icon in the bottom navigation, then choose to scan a barcode, receipt, or take a photo of your pantry shelf. Our AI will automatically identify and add items.',
  },
  {
    question: 'How does the expiration tracking work?',
    answer:
      'DinnerPlans uses product databases and AI to estimate expiration dates. You can manually adjust these dates by tapping on any item in your pantry.',
  },
  {
    question: 'Can I share my pantry with family members?',
    answer:
      'Yes! Create a household in Settings > Household, then invite family members via email. Everyone in the household can view and manage the shared pantry.',
  },
  {
    question: 'How do recipe suggestions work?',
    answer:
      'Our AI analyzes your pantry contents and suggests recipes that use ingredients you already have, prioritizing items that are expiring soon.',
  },
  {
    question: 'How do I import recipes from social media?',
    answer:
      'Use the share feature from Instagram, TikTok, or any website to send the recipe link to DinnerPlans. Our AI will extract the ingredients and instructions.',
  },
  {
    question: 'What happens when I mark a meal as completed?',
    answer:
      'When you complete a meal, DinnerPlans can automatically deduct the used ingredients from your pantry, keeping your inventory accurate.',
  },
  {
    question: 'How do I cancel my subscription?',
    answer:
      'Subscriptions are managed through your device. On iOS, go to Settings > Apple ID > Subscriptions. On Android, go to Google Play Store > Subscriptions.',
  },
];

export default function HelpScreen() {
  const { user } = useAuth();
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);
  const [feedbackText, setFeedbackText] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleEmailSupport = () => {
    Linking.openURL('mailto:support@dinnerplans.app?subject=Support Request');
  };

  const handleSubmitFeedback = async () => {
    if (!feedbackText.trim()) {
      Alert.alert('Error', 'Please enter your feedback');
      return;
    }
    setIsSubmitting(true);
    try {
      // In production, send to your backend
      await new Promise((resolve) => setTimeout(resolve, 1000));
      Alert.alert('Thank You!', 'Your feedback has been submitted.');
      setFeedbackText('');
    } catch (error) {
      Alert.alert('Error', 'Failed to submit feedback. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const toggleFAQ = (index: number) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  return (
    <ScrollView style={styles.container} contentContainerStyle={styles.content}>
      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Contact Support</Text>
        <View style={styles.card}>
          <TouchableOpacity style={styles.contactItem} onPress={handleEmailSupport}>
            <View style={styles.contactIcon}>
              <Ionicons name="mail-outline" size={24} color="#4CAF50" />
            </View>
            <View style={styles.contactInfo}>
              <Text style={styles.contactTitle}>Email Support</Text>
              <Text style={styles.contactSubtitle}>
                Get help from our support team
              </Text>
            </View>
            <Ionicons name="chevron-forward" size={20} color="#ccc" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
        <View style={styles.card}>
          {FAQ_ITEMS.map((item, index) => (
            <View key={index}>
              {index > 0 && <View style={styles.faqDivider} />}
              <TouchableOpacity
                style={styles.faqItem}
                onPress={() => toggleFAQ(index)}
              >
                <Text style={styles.faqQuestion}>{item.question}</Text>
                <Ionicons
                  name={expandedFAQ === index ? 'chevron-up' : 'chevron-down'}
                  size={20}
                  color="#666"
                />
              </TouchableOpacity>
              {expandedFAQ === index && (
                <View style={styles.faqAnswer}>
                  <Text style={styles.faqAnswerText}>{item.answer}</Text>
                </View>
              )}
            </View>
          ))}
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Send Feedback</Text>
        <View style={styles.card}>
          <View style={styles.feedbackContainer}>
            <Text style={styles.feedbackLabel}>
              Help us improve DinnerPlans
            </Text>
            <TextInput
              style={styles.feedbackInput}
              placeholder="Tell us what you think, report bugs, or suggest features..."
              placeholderTextColor="#999"
              multiline
              numberOfLines={4}
              textAlignVertical="top"
              value={feedbackText}
              onChangeText={setFeedbackText}
            />
            <Button
              title={isSubmitting ? 'Submitting...' : 'Submit Feedback'}
              onPress={handleSubmitFeedback}
              disabled={isSubmitting}
            />
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>Resources</Text>
        <View style={styles.card}>
          <TouchableOpacity
            style={styles.resourceItem}
            onPress={() => Linking.openURL('https://dinnerplans.app/privacy')}
          >
            <Ionicons name="shield-checkmark-outline" size={22} color="#333" />
            <Text style={styles.resourceText}>Privacy Policy</Text>
            <Ionicons name="open-outline" size={16} color="#999" />
          </TouchableOpacity>
          <View style={styles.resourceDivider} />
          <TouchableOpacity
            style={styles.resourceItem}
            onPress={() => Linking.openURL('https://dinnerplans.app/terms')}
          >
            <Ionicons name="document-text-outline" size={22} color="#333" />
            <Text style={styles.resourceText}>Terms of Service</Text>
            <Ionicons name="open-outline" size={16} color="#999" />
          </TouchableOpacity>
          <View style={styles.resourceDivider} />
          <TouchableOpacity
            style={styles.resourceItem}
            onPress={() => Linking.openURL('https://dinnerplans.app')}
          >
            <Ionicons name="globe-outline" size={22} color="#333" />
            <Text style={styles.resourceText}>Website</Text>
            <Ionicons name="open-outline" size={16} color="#999" />
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.appInfo}>
        <Text style={styles.appName}>DinnerPlans</Text>
        <Text style={styles.appVersion}>Version 1.3.1</Text>
        <Text style={styles.copyright}>© 2024 DinnerPlans. All rights reserved.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  content: {
    padding: 16,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '600',
    color: '#666',
    textTransform: 'uppercase',
    marginBottom: 8,
    marginLeft: 4,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 12,
    overflow: 'hidden',
  },
  contactItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  contactIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#E8F5E9',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  contactInfo: {
    flex: 1,
  },
  contactTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
  },
  contactSubtitle: {
    fontSize: 14,
    color: '#666',
    marginTop: 2,
  },
  faqItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  faqQuestion: {
    flex: 1,
    fontSize: 15,
    fontWeight: '500',
    color: '#333',
    marginRight: 12,
  },
  faqDivider: {
    height: 1,
    backgroundColor: '#f0f0f0',
  },
  faqAnswer: {
    paddingHorizontal: 16,
    paddingBottom: 16,
  },
  faqAnswerText: {
    fontSize: 14,
    color: '#666',
    lineHeight: 22,
  },
  feedbackContainer: {
    padding: 16,
  },
  feedbackLabel: {
    fontSize: 14,
    color: '#666',
    marginBottom: 12,
  },
  feedbackInput: {
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    padding: 12,
    fontSize: 16,
    minHeight: 100,
    marginBottom: 16,
    color: '#333',
  },
  resourceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  resourceText: {
    flex: 1,
    fontSize: 16,
    color: '#333',
    marginLeft: 12,
  },
  resourceDivider: {
    height: 1,
    backgroundColor: '#f0f0f0',
    marginLeft: 50,
  },
  appInfo: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  appName: {
    fontSize: 18,
    fontWeight: '600',
    color: '#333',
  },
  appVersion: {
    fontSize: 14,
    color: '#666',
    marginTop: 4,
  },
  copyright: {
    fontSize: 12,
    color: '#999',
    marginTop: 8,
  },
});

